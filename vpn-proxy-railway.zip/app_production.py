#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sqlite3
import hashlib
import secrets
import base64
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import requests

# 生产环境配置
class ProductionConfig:
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    DATABASE_PATH = os.environ.get('DATABASE_PATH') or '/var/www/vpn/vpn.db'
    UPSTREAM_URL = os.environ.get('UPSTREAM_URL') or ''
    HOST = '0.0.0.0'
    PORT = int(os.environ.get('PORT', 5000))
    DEBUG = False

app = Flask(__name__)
app.config.from_object(ProductionConfig)

def init_db():
    """初始化数据库"""
    conn = sqlite3.connect(app.config['DATABASE_PATH'])
    c = conn.cursor()
    
    # 创建用户表
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        subscription_key TEXT UNIQUE NOT NULL,
        expire_date TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        traffic_used INTEGER DEFAULT 0,
        traffic_limit INTEGER DEFAULT 107374182400
    )''')
    
    # 创建节点表
    c.execute('''CREATE TABLE IF NOT EXISTS nodes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        server TEXT NOT NULL,
        port INTEGER NOT NULL,
        password TEXT,
        method TEXT,
        location TEXT,
        config TEXT
    )''')
    
    # 创建管理员账户
    admin_password = hashlib.sha256('admin123'.encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO users (username, password, subscription_key, expire_date, is_admin) VALUES (?, ?, ?, ?, ?)',
              ('admin', admin_password, 'admin_key', '2099-12-31', 1))
    
    # 创建测试用户
    user_password = hashlib.sha256('user123'.encode()).hexdigest()
    user_key = secrets.token_urlsafe(32)
    c.execute('INSERT OR IGNORE INTO users (username, password, subscription_key, expire_date) VALUES (?, ?, ?, ?)',
              ('testuser', user_password, user_key, '2024-12-31'))
    
    conn.commit()
    conn.close()

def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(app.config['DATABASE_PATH'])
    conn.row_factory = sqlite3.Row
    return conn

def parse_subscription_content(content):
    """解析订阅内容"""
    nodes = []
    
    try:
        decoded_content = base64.b64decode(content).decode('utf-8')
        lines = decoded_content.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            try:
                if line.startswith('vless://'):
                    node = parse_vless(line)
                elif line.startswith('vmess://'):
                    node = parse_vmess(line)
                elif line.startswith('ss://'):
                    node = parse_shadowsocks(line)
                elif line.startswith('trojan://'):
                    node = parse_trojan(line)
                else:
                    continue
                    
                if node:
                    nodes.append(node)
                    
            except Exception as e:
                print(f"解析节点失败: {line[:50]}... 错误: {e}")
                continue
                
    except Exception as e:
        print(f"解析订阅内容失败: {e}")
        
    return nodes

def parse_vless(url):
    """解析VLESS协议"""
    try:
        from urllib.parse import urlparse, parse_qs, unquote
        parsed = urlparse(url)
        
        uuid = parsed.username
        server = parsed.hostname
        port = parsed.port or 443
        
        params = parse_qs(parsed.query)
        name = unquote(parsed.fragment) if parsed.fragment else f"{server}:{port}"
        
        return {
            'name': name,
            'server': server,
            'port': port,
            'password': uuid,
            'method': 'vless',
            'location': '未知',
            'config': url
        }
    except Exception as e:
        print(f"解析VLESS失败: {e}")
        return None

def parse_vmess(url):
    """解析VMess协议"""
    try:
        content = url[8:]  # 移除 'vmess://'
        decoded = base64.b64decode(content).decode('utf-8')
        config = json.loads(decoded)
        
        return {
            'name': config.get('ps', f"{config.get('add')}:{config.get('port')}"),
            'server': config.get('add'),
            'port': int(config.get('port', 443)),
            'password': config.get('id'),
            'method': 'vmess',
            'location': '未知',
            'config': url
        }
    except Exception as e:
        print(f"解析VMess失败: {e}")
        return None

def parse_shadowsocks(url):
    """解析Shadowsocks协议"""
    try:
        from urllib.parse import urlparse, unquote
        parsed = urlparse(url)
        
        if '@' in parsed.netloc:
            # 新格式: ss://method:password@server:port#name
            auth_part = parsed.username
            if ':' in auth_part:
                method, password = auth_part.split(':', 1)
            else:
                # Base64编码的认证信息
                decoded_auth = base64.b64decode(auth_part).decode('utf-8')
                method, password = decoded_auth.split(':', 1)
            
            server = parsed.hostname
            port = parsed.port or 443
        else:
            # 旧格式: ss://base64(method:password@server:port)#name
            decoded = base64.b64decode(parsed.netloc).decode('utf-8')
            auth_server = decoded.split('@')
            method, password = auth_server[0].split(':', 1)
            server, port = auth_server[1].split(':')
            port = int(port)
        
        name = unquote(parsed.fragment) if parsed.fragment else f"{server}:{port}"
        
        return {
            'name': name,
            'server': server,
            'port': port,
            'password': password,
            'method': method,
            'location': '未知',
            'config': url
        }
    except Exception as e:
        print(f"解析Shadowsocks失败: {e}")
        return None

def parse_trojan(url):
    """解析Trojan协议"""
    try:
        from urllib.parse import urlparse, unquote
        parsed = urlparse(url)
        
        password = parsed.username
        server = parsed.hostname
        port = parsed.port or 443
        name = unquote(parsed.fragment) if parsed.fragment else f"{server}:{port}"
        
        return {
            'name': name,
            'server': server,
            'port': port,
            'password': password,
            'method': 'trojan',
            'location': '未知',
            'config': url
        }
    except Exception as e:
        print(f"解析Trojan失败: {e}")
        return None

# ... 这里包含所有路由函数 ...
# (为了节省空间，我会在下一个文件中包含所有路由)

if __name__ == '__main__':
    # 确保数据库目录存在
    db_dir = os.path.dirname(app.config['DATABASE_PATH'])
    if not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)
    
    init_db()
    
    print(f"🚀 VPN机场启动在: {app.config['HOST']}:{app.config['PORT']}")
    print(f"📊 数据库路径: {app.config['DATABASE_PATH']}")
    print(f"🔗 上游URL: {app.config['UPSTREAM_URL'][:50]}..." if app.config['UPSTREAM_URL'] else "🔗 未配置上游URL")
    
    app.run(
        host=app.config['HOST'],
        port=app.config['PORT'],
        debug=app.config['DEBUG']
    ) 