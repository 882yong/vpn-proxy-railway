#!/usr/bin/env python3
"""
部署测试脚本 - 验证VPN面板功能
"""

import requests
import json
import time
import sys

def test_health_check(base_url):
    """测试健康检查"""
    try:
        response = requests.get(f"{base_url}/", timeout=10)
        if response.status_code == 200:
            print("✅ 健康检查通过")
            return True
        else:
            print(f"❌ 健康检查失败: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 连接失败: {e}")
        return False

def test_user_registration(base_url):
    """测试用户注册"""
    try:
        # 测试注册页面
        response = requests.get(f"{base_url}/register", timeout=10)
        if response.status_code == 200:
            print("✅ 注册页面可访问")
        else:
            print(f"⚠️  注册页面状态码: {response.status_code}")
        
        # 测试注册功能
        test_user = {
            'username': f'test_user_{int(time.time())}',
            'password': 'test_password_123',
            'email': f'test_{int(time.time())}@example.com'
        }
        
        response = requests.post(f"{base_url}/register", data=test_user, timeout=10)
        if response.status_code in [200, 302]:  # 成功或重定向
            print("✅ 用户注册功能正常")
            return test_user
        else:
            print(f"⚠️  注册功能状态码: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"❌ 注册测试失败: {e}")
        return None

def test_subscription_endpoint(base_url):
    """测试订阅端点"""
    try:
        # 测试订阅端点（使用假的用户密钥）
        test_key = "test_key_12345"
        response = requests.get(f"{base_url}/subscription/{test_key}", timeout=10)
        
        # 即使没有真实用户，端点也应该能响应
        if response.status_code in [200, 404]:
            print("✅ 订阅端点可访问")
            return True
        else:
            print(f"⚠️  订阅端点状态码: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ 订阅端点测试失败: {e}")
        return False

def test_admin_panel(base_url):
    """测试管理员面板"""
    try:
        response = requests.get(f"{base_url}/admin", timeout=10)
        if response.status_code in [200, 302, 401]:  # 可能需要登录
            print("✅ 管理员面板可访问")
            return True
        else:
            print(f"⚠️  管理员面板状态码: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 管理员面板测试失败: {e}")
        return False

def run_comprehensive_test(base_url):
    """运行综合测试"""
    print(f"🧪 开始测试VPN面板: {base_url}")
    print("=" * 60)
    
    results = {
        'health_check': test_health_check(base_url),
        'user_registration': test_user_registration(base_url) is not None,
        'subscription_endpoint': test_subscription_endpoint(base_url),
        'admin_panel': test_admin_panel(base_url)
    }
    
    print("\n📊 测试结果汇总:")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{test_name.replace('_', ' ').title()}: {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 总体结果: {passed}/{total} 项测试通过")
    
    if passed == total:
        print("🎉 恭喜！所有功能测试通过，VPN面板部署成功！")
        print("\n📝 下一步操作:")
        print("1. 访问管理员面板修改默认密码")
        print("2. 配置上游订阅链接")
        print("3. 开始邀请用户注册")
        return True
    else:
        print("⚠️  部分功能可能存在问题，请检查部署配置")
        return False

def main():
    """主函数"""
    if len(sys.argv) != 2:
        print("使用方法: python test_deployment.py <部署URL>")
        print("示例: python test_deployment.py https://your-app.railway.app")
        return
    
    base_url = sys.argv[1].rstrip('/')
    
    # 等待服务启动
    print("⏳ 等待服务启动...")
    time.sleep(5)
    
    # 运行测试
    success = run_comprehensive_test(base_url)
    
    if success:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main() 