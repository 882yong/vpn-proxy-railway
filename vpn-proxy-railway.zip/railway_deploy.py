# Railway.app 免费部署配置

# 1. 创建 requirements.txt
"""
Flask==2.3.3
requests==2.31.0
gunicorn==21.2.0
"""

# 2. 创建 Procfile
"""
web: gunicorn app:app --bind 0.0.0.0:$PORT
"""

# 3. 修改 app.py 的最后部分
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

# 部署步骤:
# 1. 注册 Railway.app 账号
# 2. 连接GitHub仓库
# 3. 设置环境变量:
#    - UPSTREAM_URL: 您的上游订阅链接
#    - SECRET_KEY: 随机密钥
# 4. 部署完成后获得 https://yourapp.railway.app 域名 