#!/usr/bin/env python3
"""
Railway.app 一键部署脚本
"""

import os
import sys
import subprocess
import secrets
import string

def generate_secret_key():
    """生成安全的密钥"""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(32))

def check_git():
    """检查Git是否安装"""
    try:
        subprocess.run(['git', '--version'], check=True, capture_output=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def check_railway_cli():
    """检查Railway CLI是否安装"""
    try:
        subprocess.run(['railway', '--version'], check=True, capture_output=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False

def install_railway_cli():
    """安装Railway CLI"""
    print("🔧 安装Railway CLI...")
    
    if sys.platform == "win32":
        print("Windows用户请手动安装Railway CLI:")
        print("1. 访问: https://docs.railway.app/develop/cli")
        print("2. 下载并安装Railway CLI")
        return False
    else:
        try:
            subprocess.run(['curl', '-sSL', 'https://railway.app/install.sh'], 
                         stdout=subprocess.PIPE, check=True)
            subprocess.run(['sh'], input=subprocess.PIPE, check=True)
            return True
        except subprocess.CalledProcessError:
            print("❌ 自动安装失败，请手动安装Railway CLI")
            return False

def init_git_repo():
    """初始化Git仓库"""
    print("📦 初始化Git仓库...")
    
    try:
        # 初始化Git仓库
        subprocess.run(['git', 'init'], check=True)
        
        # 添加所有文件
        subprocess.run(['git', 'add', '.'], check=True)
        
        # 提交
        subprocess.run(['git', 'commit', '-m', 'Initial commit for Railway deployment'], check=True)
        
        print("✅ Git仓库初始化完成")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Git初始化失败: {e}")
        return False

def deploy_to_railway():
    """部署到Railway"""
    print("🚀 开始部署到Railway...")
    
    try:
        # 登录Railway
        print("请在浏览器中完成Railway登录...")
        subprocess.run(['railway', 'login'], check=True)
        
        # 创建新项目
        subprocess.run(['railway', 'init'], check=True)
        
        # 设置环境变量
        upstream_url = input("请输入您的上游订阅链接: ").strip()
        if not upstream_url:
            print("❌ 上游订阅链接不能为空")
            return False
            
        secret_key = generate_secret_key()
        
        subprocess.run(['railway', 'variables', 'set', f'UPSTREAM_URL={upstream_url}'], check=True)
        subprocess.run(['railway', 'variables', 'set', f'SECRET_KEY={secret_key}'], check=True)
        subprocess.run(['railway', 'variables', 'set', 'DEBUG=false'], check=True)
        
        # 部署
        subprocess.run(['railway', 'up'], check=True)
        
        print("🎉 部署成功！")
        print("\n📋 部署信息:")
        print(f"上游链接: {upstream_url}")
        print(f"密钥: {secret_key}")
        print("\n🌐 获取访问链接:")
        print("运行: railway domain")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ 部署失败: {e}")
        return False
    except KeyboardInterrupt:
        print("\n❌ 部署被用户取消")
        return False

def main():
    """主函数"""
    print("🚀 Railway.app 一键部署脚本")
    print("=" * 50)
    
    # 检查Git
    if not check_git():
        print("❌ 请先安装Git: https://git-scm.com/")
        return
    
    # 检查Railway CLI
    if not check_railway_cli():
        print("⚠️  未检测到Railway CLI")
        install_cli = input("是否自动安装Railway CLI? (y/N): ").strip().lower()
        if install_cli == 'y':
            if not install_railway_cli():
                return
        else:
            print("请手动安装Railway CLI: https://docs.railway.app/develop/cli")
            return
    
    # 初始化Git仓库
    if not os.path.exists('.git'):
        if not init_git_repo():
            return
    
    # 部署到Railway
    if deploy_to_railway():
        print("\n🎉 恭喜！您的VPN面板已成功部署到Railway！")
        print("\n📝 下一步操作:")
        print("1. 运行 'railway domain' 获取访问链接")
        print("2. 访问面板并修改管理员密码")
        print("3. 开始邀请用户注册")
    else:
        print("\n❌ 部署失败，请检查错误信息")

if __name__ == "__main__":
    main() 