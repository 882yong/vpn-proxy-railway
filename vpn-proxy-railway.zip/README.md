# 🚀 VPN订阅管理面板

一个功能完整的VPN订阅管理系统，支持用户注册、订阅管理、流量统计等功能。

## ✨ 主要功能

- 🔐 用户注册登录系统
- 📱 订阅链接管理
- 📊 流量统计和使用监控
- 💰 套餐管理和购买
- 🎯 推广返利系统
- 📈 管理员后台

## 🚀 快速部署到Railway.app

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/deploy)

### 环境变量配置

| 变量名 | 说明 | 示例 |
|--------|------|------|
| `UPSTREAM_URL` | 上游订阅链接 | `https://example.com/sub/xxxxx` |
| `SECRET_KEY` | 应用密钥 | `your-super-secret-key` |
| `DEBUG` | 调试模式 | `false` |

## 📱 本地运行

```bash
# 安装依赖
pip install -r requirements.txt

# 设置环境变量
export UPSTREAM_URL="your-upstream-url"
export SECRET_KEY="your-secret-key"

# 运行应用
python app.py
```

## 🌐 访问地址

部署成功后，您将获得：
- 管理面板: `https://yourapp.railway.app`
- 订阅链接: `https://yourapp.railway.app/subscription/{user_key}`

## 📞 技术支持

如有问题，请提交Issue或联系技术支持。 