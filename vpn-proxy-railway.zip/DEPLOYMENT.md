# 🚀 Railway.app 免费部署指南

## 📋 准备工作

### 1. 获取上游订阅链接
首先您需要有一个上游VPN提供商的订阅链接，格式通常如下：
```
https://example.com/sub/abcd1234
```

### 2. 准备GitHub账号
确保您有GitHub账号，用于托管代码。

## 🚀 部署步骤

### 第一步：上传代码到GitHub

1. **创建新仓库**
   - 访问 [GitHub](https://github.com)
   - 点击 "New repository"
   - 仓库名: `vpn-panel`
   - 选择 "Public" 或 "Private"
   - 点击 "Create repository"

2. **上传代码**
   ```bash
   # 在项目目录中执行
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/vpn-panel.git
   git push -u origin main
   ```

### 第二步：部署到Railway.app

1. **注册Railway账号**
   - 访问 [Railway.app](https://railway.app)
   - 使用GitHub账号登录

2. **创建新项目**
   - 点击 "New Project"
   - 选择 "Deploy from GitHub repo"
   - 选择您刚创建的 `vpn-panel` 仓库
   - 点击 "Deploy Now"

3. **配置环境变量**
   - 在项目面板中点击 "Variables"
   - 添加以下环境变量：

   | 变量名 | 值 | 说明 |
   |--------|-----|------|
   | `UPSTREAM_URL` | `https://your-provider.com/sub/xxxxx` | 您的上游订阅链接 |
   | `SECRET_KEY` | `your-super-secret-key-change-this` | 应用密钥（请修改） |
   | `DEBUG` | `false` | 生产环境关闭调试 |

4. **等待部署完成**
   - Railway会自动检测Python项目
   - 安装依赖并启动服务
   - 部署成功后会显示访问链接

## 🌐 访问您的VPN面板

部署成功后，您将获得类似这样的链接：
```
https://vpn-panel-production-xxxx.up.railway.app
```

### 管理员账号
首次访问时会自动创建管理员账号：
- 用户名: `admin`
- 密码: `admin123`

**⚠️ 重要：请立即修改管理员密码！**

## 📱 用户使用指南

### 用户注册和订阅
1. 用户访问您的面板链接
2. 注册新账号
3. 登录后获得个人订阅链接：
   ```
   https://your-panel.railway.app/subscription/user_key
   ```

### VPN客户端配置
用户可以将订阅链接添加到以下客户端：

**iOS:**
- Shadowrocket
- Quantumult X

**Android:**
- Shadowsocks
- V2rayNG

**Windows:**
- V2rayN
- Shadowsocks

**macOS:**
- ClashX
- ShadowsocksX-NG

## 🔧 高级配置

### 自定义域名
1. 在Railway项目设置中点击 "Domains"
2. 点击 "Custom Domain"
3. 输入您的域名（需要先配置DNS）

### 数据库备份
Railway会自动处理数据持久化，但建议定期备份：
- 在管理员面板中可以导出用户数据
- 数据库文件会自动持久化

### 监控和日志
- 在Railway面板中可以查看应用日志
- 监控CPU、内存使用情况
- 设置告警通知

## 💰 费用说明

### Railway免费额度
- **每月500小时运行时间**
- **512MB内存**
- **1GB磁盘空间**
- **无限带宽**

### 超出免费额度
如果超出免费额度，Railway会按使用量计费：
- CPU: $0.000463/vCPU/分钟
- 内存: $0.000231/GB/分钟

## 🛠️ 故障排除

### 常见问题

1. **部署失败**
   - 检查requirements.txt格式
   - 确保Procfile正确配置
   - 查看部署日志

2. **订阅链接无效**
   - 检查UPSTREAM_URL环境变量
   - 确认上游链接可正常访问
   - 查看应用日志

3. **无法访问面板**
   - 检查Railway项目状态
   - 确认域名配置正确
   - 查看健康检查状态

### 获取帮助
- Railway文档: https://docs.railway.app
- 项目Issues: 在GitHub仓库中提交问题
- 社区支持: Railway Discord

## 🔒 安全建议

1. **修改默认密码**
   - 立即更改admin账号密码
   - 使用强密码

2. **环境变量安全**
   - SECRET_KEY使用随机字符串
   - 不要在代码中硬编码敏感信息

3. **定期更新**
   - 关注项目更新
   - 及时修复安全漏洞

## 🎉 部署完成！

恭喜！您已成功部署VPN订阅管理面板。现在您可以：

1. 访问管理面板管理用户
2. 分享注册链接给用户
3. 监控使用情况和流量
4. 根据需要调整配置

祝您使用愉快！ 🚀 