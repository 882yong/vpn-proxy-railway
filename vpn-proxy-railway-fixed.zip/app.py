from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import hashlib
import secrets
import base64
import json
import requests
import urllib.parse
import re
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# 初始化数据库
def init_db():
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    # 用户表（添加is_admin字段）
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, 
                  subscription_key TEXT, expire_date TEXT, traffic_used INTEGER DEFAULT 0,
                  traffic_limit INTEGER DEFAULT 107374182400, is_admin INTEGER DEFAULT 0)''')
    
    # VPN节点表
    c.execute('''CREATE TABLE IF NOT EXISTS nodes
                 (id INTEGER PRIMARY KEY, name TEXT, server TEXT, port INTEGER, 
                  method TEXT, password TEXT, location TEXT)''')
    
    # 创建默认管理员账号 admin/admin123
    admin_password = hashlib.sha256('admin123'.encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO users (username, password, subscription_key, expire_date, is_admin) VALUES (?, ?, ?, ?, ?)',
              ('admin', admin_password, 'admin_key', '2099-12-31', 1))
    
    # 添加默认节点
    nodes = [
        ('美国节点1', 'us1.example.com', 443, 'aes-256-gcm', 'password123', '美国'),
        ('日本节点1', 'jp1.example.com', 443, 'aes-256-gcm', 'password123', '日本'),
        ('香港节点1', 'hk1.example.com', 443, 'aes-256-gcm', 'password123', '香港'),
    ]
    
    c.executemany('INSERT OR IGNORE INTO nodes (name, server, port, method, password, location) VALUES (?, ?, ?, ?, ?, ?)', nodes)
    
    conn.commit()
    conn.close()

# 管理员权限验证装饰器
def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        conn = sqlite3.connect('vpn.db')
        c = conn.cursor()
        c.execute('SELECT is_admin FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        
        if not user or not user[0]:
            return redirect(url_for('dashboard'))
        
        return f(*args, **kwargs)
    return decorated_function

# 主页
@app.route('/')
def index():
    return render_template('index.html')

# 注册
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # 密码哈希
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        # 生成订阅密钥
        subscription_key = secrets.token_urlsafe(32)
        
        # 设置过期时间（30天后）
        expire_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
        
        conn = sqlite3.connect('vpn.db')
        c = conn.cursor()
        
        try:
            c.execute('INSERT INTO users (username, password, subscription_key, expire_date) VALUES (?, ?, ?, ?)',
                     (username, password_hash, subscription_key, expire_date))
            conn.commit()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            return render_template('register.html', error='用户名已存在')
        finally:
            conn.close()
    
    return render_template('register.html')

# 登录
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = sqlite3.connect('vpn.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password_hash))
        user = c.fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['is_admin'] = user[7] if len(user) > 7 else 0
            
            # 管理员直接跳转到后台
            if session.get('is_admin'):
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='用户名或密码错误')
    
    return render_template('login.html')

# 仪表板
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    # 获取用户信息
    c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = c.fetchone()
    
    # 获取节点列表
    c.execute('SELECT * FROM nodes')
    nodes = c.fetchall()
    
    conn.close()
    
    # 计算剩余流量
    traffic_remaining = user[6] - user[5]  # traffic_limit - traffic_used
    traffic_remaining_gb = traffic_remaining / (1024**3)
    
    # 生成订阅链接
    subscription_url = f"http://localhost:5000/subscription/{user[3]}" if user else ""
    
    return render_template('dashboard.html', 
                         user=user, 
                         nodes=nodes, 
                         traffic_remaining_gb=round(traffic_remaining_gb, 2),
                         subscription_url=subscription_url)

# 订阅链接
@app.route('/subscription/<subscription_key>')
def subscription(subscription_key):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    # 验证订阅密钥
    c.execute('SELECT * FROM users WHERE subscription_key = ?', (subscription_key,))
    user = c.fetchone()
    
    if not user:
        return "无效的订阅链接", 404
    
    # 检查是否过期
    expire_date = datetime.strptime(user[4], '%Y-%m-%d')
    if datetime.now() > expire_date:
        return "订阅已过期", 403
    
    # 获取节点列表
    c.execute('SELECT * FROM nodes')
    nodes = c.fetchall()
    conn.close()
    
    # 生成Shadowsocks配置
    configs = []
    for node in nodes:
        config = {
            "server": node[2],
            "server_port": node[3],
            "method": node[4],
            "password": node[5],
            "remarks": node[1],
            "route": "bypass-lan-china"
        }
        configs.append(config)
    
    # 转换为base64编码的订阅格式
    config_json = json.dumps(configs, ensure_ascii=False)
    config_b64 = base64.b64encode(config_json.encode('utf-8')).decode('utf-8')
    
    return config_b64, 200, {'Content-Type': 'text/plain'}

# 登出
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# 管理员仪表板
@app.route('/admin')
@admin_required
def admin_dashboard():
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    # 获取统计数据
    c.execute('SELECT COUNT(*) FROM users WHERE is_admin = 0')
    user_count = c.fetchone()[0]
    
    c.execute('SELECT COUNT(*) FROM nodes')
    node_count = c.fetchone()[0]
    
    # 获取最近注册的用户
    c.execute('SELECT id, username, expire_date FROM users WHERE is_admin = 0 ORDER BY id DESC LIMIT 5')
    recent_users = c.fetchall()
    
    conn.close()
    
    return render_template('admin/dashboard.html', 
                         user_count=user_count,
                         node_count=node_count,
                         recent_users=recent_users)

# 用户管理
@app.route('/admin/users')
@admin_required
def admin_users():
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    c.execute('SELECT id, username, expire_date, traffic_used, traffic_limit FROM users WHERE is_admin = 0')
    users = c.fetchall()
    conn.close()
    
    return render_template('admin/users.html', users=users)

# 编辑用户
@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def admin_edit_user(user_id):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    if request.method == 'POST':
        expire_date = request.form['expire_date']
        traffic_limit = int(request.form['traffic_limit']) * 1024**3  # GB to bytes
        
        c.execute('UPDATE users SET expire_date = ?, traffic_limit = ? WHERE id = ?',
                  (expire_date, traffic_limit, user_id))
        conn.commit()
        conn.close()
        return redirect(url_for('admin_users'))
    
    c.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    user = c.fetchone()
    conn.close()
    
    return render_template('admin/edit_user.html', user=user)

# 删除用户
@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@admin_required
def admin_delete_user(user_id):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    c.execute('DELETE FROM users WHERE id = ? AND is_admin = 0', (user_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_users'))

# 节点管理
@app.route('/admin/nodes')
@admin_required
def admin_nodes():
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    c.execute('SELECT * FROM nodes')
    nodes = c.fetchall()
    conn.close()
    
    return render_template('admin/nodes.html', nodes=nodes)

# 添加节点
@app.route('/admin/nodes/add', methods=['GET', 'POST'])
@admin_required
def admin_add_node():
    if request.method == 'POST':
        name = request.form['name']
        server = request.form['server']
        port = int(request.form['port'])
        method = request.form['method']
        password = request.form['password']
        location = request.form['location']
        
        conn = sqlite3.connect('vpn.db')
        c = conn.cursor()
        c.execute('INSERT INTO nodes (name, server, port, method, password, location) VALUES (?, ?, ?, ?, ?, ?)',
                  (name, server, port, method, password, location))
        conn.commit()
        conn.close()
        
        return redirect(url_for('admin_nodes'))
    
    return render_template('admin/add_node.html')

# 编辑节点
@app.route('/admin/nodes/<int:node_id>/edit', methods=['GET', 'POST'])
@admin_required
def admin_edit_node(node_id):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    if request.method == 'POST':
        name = request.form['name']
        server = request.form['server']
        port = int(request.form['port'])
        method = request.form['method']
        password = request.form['password']
        location = request.form['location']
        
        c.execute('UPDATE nodes SET name = ?, server = ?, port = ?, method = ?, password = ?, location = ? WHERE id = ?',
                  (name, server, port, method, password, location, node_id))
        conn.commit()
        conn.close()
        return redirect(url_for('admin_nodes'))
    
    c.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
    node = c.fetchone()
    conn.close()
    
    return render_template('admin/edit_node.html', node=node)

# 删除节点
@app.route('/admin/nodes/<int:node_id>/delete', methods=['POST'])
@admin_required
def admin_delete_node(node_id):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    c.execute('DELETE FROM nodes WHERE id = ?', (node_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_nodes'))

# 上游节点同步配置
UPSTREAM_URL = "https://liangxin.xyz/api/v1/liangxin?OwO=8cf7eb544597cc8399f4fd0641520d1a"

def parse_vless_url(url):
    """解析vless://协议的URL"""
    try:
        # 移除协议前缀
        url_without_protocol = url.replace('vless://', '')
        
        # 分离用户信息和参数
        if '@' in url_without_protocol:
            uuid_part, rest = url_without_protocol.split('@', 1)
            if '#' in rest:
                server_part, name_part = rest.rsplit('#', 1)
                name = urllib.parse.unquote(name_part)
            else:
                server_part = rest
                name = "Unknown"
                
            # 解析服务器和端口
            if '?' in server_part:
                server_port, params_str = server_part.split('?', 1)
            else:
                server_port = server_part
                params_str = ""
                
            if ':' in server_port:
                server, port = server_port.rsplit(':', 1)
            else:
                server = server_port
                port = "443"
                
            return {
                'name': name,
                'server': server,
                'port': int(port),
                'node_type': 'vless',
                'config': url  # 保存完整配置
            }
    except Exception as e:
        print(f"解析vless URL失败: {e}")
        return None

def parse_vmess_url(url):
    """解析vmess://协议的URL"""
    try:
        # 移除协议前缀
        url_without_protocol = url.replace('vmess://', '')
        
        # Base64解码
        decoded = base64.b64decode(url_without_protocol).decode('utf-8')
        config = json.loads(decoded)
        
        return {
            'name': config.get('ps', 'Unknown'),
            'server': config.get('add', ''),
            'port': int(config.get('port', 443)),
            'node_type': 'vmess',
            'config': url
        }
    except Exception as e:
        print(f"解析vmess URL失败: {e}")
        return None

def parse_ss_url(url):
    """解析ss://协议的URL"""
    try:
        # 移除协议前缀
        url_without_protocol = url.replace('ss://', '')
        
        if '#' in url_without_protocol:
            config_part, name = url_without_protocol.rsplit('#', 1)
            name = urllib.parse.unquote(name)
        else:
            config_part = url_without_protocol
            name = "Unknown"
            
        # Base64解码配置部分
        if '@' in config_part:
            # 新格式: method:password@server:port
            auth_part, server_part = config_part.split('@', 1)
            try:
                decoded_auth = base64.b64decode(auth_part).decode('utf-8')
                method, password = decoded_auth.split(':', 1)
            except:
                method, password = auth_part.split(':', 1)
                
            server, port = server_part.split(':', 1)
        else:
            # 旧格式: 全部base64编码
            decoded = base64.b64decode(config_part).decode('utf-8')
            method, password, server, port = decoded.replace('@', ':').split(':')
            
        return {
            'name': name,
            'server': server,
            'port': int(port),
            'node_type': 'shadowsocks',
            'config': url
        }
    except Exception as e:
        print(f"解析ss URL失败: {e}")
        return None

def sync_upstream_nodes():
    """从上游API同步节点"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(UPSTREAM_URL, headers=headers, timeout=30)
        if response.status_code != 200:
            return False, f"请求失败: {response.status_code}"
            
        # Base64解码订阅内容
        try:
            decoded_content = base64.b64decode(response.text).decode('utf-8')
        except:
            decoded_content = response.text
            
        # 按行分割节点
        node_lines = [line.strip() for line in decoded_content.split('\n') if line.strip()]
        
        parsed_nodes = []
        for line in node_lines:
            node_data = None
            if line.startswith('vless://'):
                node_data = parse_vless_url(line)
            elif line.startswith('vmess://'):
                node_data = parse_vmess_url(line)
            elif line.startswith('ss://'):
                node_data = parse_ss_url(line)
            elif line.startswith('trojan://'):
                # 简单处理trojan协议
                try:
                    url_without_protocol = line.replace('trojan://', '')
                    if '@' in url_without_protocol and '#' in url_without_protocol:
                        password_part, rest = url_without_protocol.split('@', 1)
                        server_part, name = rest.rsplit('#', 1)
                        server, port = server_part.split(':', 1) if ':' in server_part else (server_part, '443')
                        node_data = {
                            'name': urllib.parse.unquote(name),
                            'server': server.split('?')[0] if '?' in server else server,
                            'port': int(port.split('?')[0]) if '?' in port else int(port),
                            'node_type': 'trojan',
                            'config': line
                        }
                except Exception as e:
                    print(f"解析trojan URL失败: {e}")
                    continue
                    
            if node_data:
                parsed_nodes.append(node_data)
                
        # 清空现有节点并插入新节点
        conn = sqlite3.connect('vpn.db')
        c = conn.cursor()
        
        # 先更新数据库结构，添加config字段（如果不存在）
        try:
            c.execute('ALTER TABLE nodes ADD COLUMN config TEXT')
        except:
            pass  # 字段已存在
            
        # 清空现有节点
        c.execute('DELETE FROM nodes WHERE 1=1')
        
        # 插入新节点
        for node in parsed_nodes:
            c.execute('''INSERT INTO nodes (name, server, port, method, password, location, config) 
                         VALUES (?, ?, ?, ?, ?, ?, ?)''',
                     (node['name'], node['server'], node['port'], 
                      node['node_type'], '', '未知', node['config']))
        
        conn.commit()
        conn.close()
        
        return True, f"成功同步 {len(parsed_nodes)} 个节点"
        
    except Exception as e:
        return False, f"同步失败: {str(e)}"

# 上游节点同步路由
@app.route('/admin/sync-nodes', methods=['POST'])
@admin_required
def admin_sync_nodes():
    success, message = sync_upstream_nodes()
    if success:
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'success': False, 'message': message})

# 用户订阅接口
@app.route('/subscription/<subscription_key>')
def user_subscription(subscription_key):
    conn = sqlite3.connect('vpn.db')
    c = conn.cursor()
    
    # 验证订阅密钥
    c.execute('SELECT username FROM users WHERE subscription_key = ? AND expire_date > ?', 
              (subscription_key, datetime.now().strftime('%Y-%m-%d')))
    user = c.fetchone()
    
    if not user:
        return "订阅已过期或无效", 404
    
    # 获取所有节点
    c.execute('SELECT * FROM nodes WHERE 1=1')
    nodes = c.fetchall()
    conn.close()
    
    # 生成订阅内容
    subscription_content = ""
    for node in nodes:
        # 如果有完整配置，直接使用
        if len(node) > 6 and node[6]:  # config字段
            subscription_content += node[6] + "\n"
        else:
            # 简化处理
            subscription_content += f"# {node[1]}\n"
    
    # Base64编码返回
    encoded_content = base64.b64encode(subscription_content.encode()).decode()
    
    response = app.response_class(
        response=encoded_content,
        status=200,
        mimetype='text/plain'
    )
    return response

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=False) 